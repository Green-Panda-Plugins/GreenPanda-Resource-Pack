# GreenPanda-Resource-Pack
Required resources for the the green/panda plugin pack
